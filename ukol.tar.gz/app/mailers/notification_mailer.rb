class NotificationMailer < ApplicationMailer
end
